# **`Unicode-Bedrock-New + The Hive`**
 **Unicode ใหม่สำหรับ Bedrock ลบเครดิต จะงดอัพเดท มีไรใหม่ๆ ไม่แจกละ งอล ชิ ><**
**Unicode ส่วนนึงเป็นของ The Hive หากไม่อยากจะใช้ ผมจะลบในส่วนของ `The Hive` ให้ครับ**


**เพื่อเป็นการขอบคุณโปรกด subscribe ช่อง | To thank the pro, press subscribe.**
https://www.youtube.com/channel/UC90J7ZO0uraH6kIjJ43v6UQ?view_as=subscriber<br>

> - <h2>How to install Unicode on mobile</h2>
[![](http://img.youtube.com/vi/GHy_qYswfz0/0.jpg)](https://youtu.be/GHy_qYswfz0)


> - <h2>Unicode usage</h2>
[![](http://img.youtube.com/vi/xJIY6p1vPdY/0.jpg)](https://youtu.be/xJIY6p1vPdY)

> - <h2>Server install usage</h2>
[![](http://img.youtube.com/vi/DOz0nD8pvnM/0.jpg)](https://youtu.be/DOz0nD8pvnM)

 > <h2>List Unicode</h2>
 
|               Name               |   Platform   | Character | Unicode |                     In game                    |
|:--------------------------------:|:------------:|:---------:|:-------:|:----------------------------------------------:|
|             U1                   |     All      |          |  -      |![9C67195C-C831-4554-B47D-21F384879A1B_4_5005_c](https://user-images.githubusercontent.com/12781303/99870260-63c0c080-2c04-11eb-8429-793f601801d4.jpeg)|
|             U2                   |     All      |          |  -      |![75EE9994-0F79-466E-8BA5-9CE0FB6B69EE_4_5005_c](https://user-images.githubusercontent.com/12781303/99870440-7b4c7900-2c05-11eb-9820-9ccad88b53d0.jpeg)|
|             U3                   |     All      |         |  -      |![2EB16FF6-10AC-4054-B588-36ACBBDB431B_4_5005_c](https://user-images.githubusercontent.com/12781303/99870455-8ef7df80-2c05-11eb-910e-6ad87cc7e964.jpeg)|
|             U4                   |     All      |          |  -      |![45B8D49E-A8C2-4DA1-BACE-7318D7DF5613_4_5005_c](https://user-images.githubusercontent.com/12781303/99870549-6fad8200-2c06-11eb-813f-3532f7d6540d.jpeg)|
|             U5                   |     All      |          |  -      |![91B27BF1-3249-439A-908A-0097FF2A4C82_4_5005_c](https://user-images.githubusercontent.com/12781303/99870583-d763cd00-2c06-11eb-97db-1c8309d7a7ec.jpeg)|
|             U6                   |     All      |          |  -      |![158D749C-6201-41CC-8D91-2342BE31E645_4_5005_c](https://user-images.githubusercontent.com/12781303/99870600-fd896d00-2c06-11eb-8428-6e07338cdfac.jpeg)|
|             U7                   |     All      |          |  -      |![FDE3F440-F41E-4303-B10F-E4BB23F9882D_4_5005_c](https://user-images.githubusercontent.com/12781303/99870602-0bd78900-2c07-11eb-94d9-e1d17f18dd9d.jpeg)|
|             U8                   |     All      |          |  -      |![76CC2B48-4132-425E-923F-8BA125B244A2_4_5005_c](https://user-images.githubusercontent.com/12781303/99870620-29a4ee00-2c07-11eb-98da-1f7779438b53.jpeg)|
|             U9                   |     All      |          |  -      |![71E3B5AE-554F-42DF-9D99-00CAFD0324EB_4_5005_c](https://user-images.githubusercontent.com/12781303/99870621-30336580-2c07-11eb-97e6-0c1e2829ce5e.jpeg)|
|             U10                   |     All      |          |  -      |![4601918C-5FDA-4BDC-A83B-EAAD2DBD93A4_4_5005_c](https://user-images.githubusercontent.com/12781303/99870626-37f30a00-2c07-11eb-983e-b1b7d3f31ec2.jpeg)|
|             U11                   |     All      |          |  -      |![74AD3042-83AB-46A8-9A6E-ADBB639560EC_4_5005_c](https://user-images.githubusercontent.com/12781303/99870668-93bd9300-2c07-11eb-976c-f3f607343800.jpeg)|
|             U12                   |     All      |          |  -      |![B0C237BF-E2D3-4EA5-80B8-E6D72FE793E9_4_5005_c](https://user-images.githubusercontent.com/12781303/99870672-9ae4a100-2c07-11eb-92de-cb598609eaad.jpeg)|
|             U13                   |     All      |          |  -      |![15102B4A-CC37-4DB0-8B2E-3EEAD8069753_4_5005_c](https://user-images.githubusercontent.com/12781303/99870754-22caab00-2c08-11eb-9686-1f763c12d45e.jpeg)|
|             U14                   |     All      |          |  -      |![8DDCC79A-7484-4CDC-9C78-C36466E9EBB9_4_5005_c](https://user-images.githubusercontent.com/12781303/99870760-29f1b900-2c08-11eb-99c9-81c82dce7721.jpeg)|
|             U15                   |     All      |          |  -      |![B6D56D27-A6F3-4FC7-97AA-D29FED1108C3_4_5005_c](https://user-images.githubusercontent.com/12781303/99870766-30803080-2c08-11eb-8b7d-5f29a6f126dc.jpeg)|
|             U16                   |     All      |          |  -      |![34BA83E0-4957-4F88-9BC7-28CDE44E7A25_4_5005_c](https://user-images.githubusercontent.com/12781303/99870771-38d86b80-2c08-11eb-81a7-043ea1fee999.jpeg)|
|             U17                   |     All      |          |  -      |![8C95E976-9F85-49E3-83F3-05D6BC21C9AA_4_5005_c](https://user-images.githubusercontent.com/12781303/99870776-40981000-2c08-11eb-8aa4-08167072b2e0.jpeg)|
|             U18                   |     All      |          |  -      |![73D21254-BA5F-4530-B08C-1B4763A53D09_4_5005_c](https://user-images.githubusercontent.com/12781303/99870779-48f04b00-2c08-11eb-8b8d-4fedeff3252d.jpeg)|
|             U19                   |     All      |          |  -      |![8284735D-AF32-412B-8269-4812663475AA_4_5005_c](https://user-images.githubusercontent.com/12781303/99870787-54437680-2c08-11eb-93a7-c7b4bad2219a.jpeg)|
|             U20                   |     All      |          |  -      |![BDEF1C8E-3CC1-4F74-9B97-FCB1BAA858D4_4_5005_c](https://user-images.githubusercontent.com/12781303/99870793-5b6a8480-2c08-11eb-9391-878441f06783.jpeg)|
|             U21                   |     All      |          |  -      |![0514AE1E-6EC0-41D9-A84D-166E91E4E431_4_5005_c](https://user-images.githubusercontent.com/12781303/99870802-75a46280-2c08-11eb-9c1c-6a6a147e0472.jpeg)|
|             U22                   |     All      |          |  -      |![15721353-4C91-4D82-94EC-4DD392865183_4_5005_c](https://user-images.githubusercontent.com/12781303/99870810-7fc66100-2c08-11eb-8761-390a3f174b3b.jpeg)|
|             U23                   |     All      |          |  -      |![2344AB67-78BB-4F21-BDEB-BBCBBD5A222B_4_5005_c](https://user-images.githubusercontent.com/12781303/99870820-8fde4080-2c08-11eb-9760-b141a755d3b6.jpeg)|
|             U24                   |     All      |          |  -      |![919ADBEF-210A-44E2-B1F3-A2BD9820C5CB_4_5005_c](https://user-images.githubusercontent.com/12781303/99870825-95d42180-2c08-11eb-8d12-16f6b21cc874.jpeg)|
|             U25                   |     All      |          |  -      |![37C6F7D5-CC9F-4613-9E28-1E44E0523DC1_4_5005_c](https://user-images.githubusercontent.com/12781303/99870833-a08eb680-2c08-11eb-808a-8663ee15f32f.jpeg)|
|             U26                   |     All      |          |  -      |![5FF1DCA3-0423-46F5-B902-216D210A4E7E_4_5005_c](https://user-images.githubusercontent.com/12781303/99870857-c61bc000-2c08-11eb-800b-eedac7aa9ada.jpeg)|
|             U27                   |     All      |          |  -      |![B0887911-AD87-4464-B0AC-099F7BAEFB40_4_5005_c](https://user-images.githubusercontent.com/12781303/99870863-ccaa3780-2c08-11eb-9806-adcfdc545b92.jpeg)|
|             U28                   |     All      |          |  -      |![A709982C-1F13-4649-AF99-8F5BF227E4F5_4_5005_c](https://user-images.githubusercontent.com/12781303/99870866-d9c72680-2c08-11eb-8296-8a159aba0f09.jpeg)|
|             U29                   |     All      |          |  -      |![D8CFF4B2-E0F9-4C67-9259-EB8B21EC4852_4_5005_c](https://user-images.githubusercontent.com/12781303/99870870-e0559e00-2c08-11eb-9d4f-324e63d39ff8.jpeg)|
|             U30                   |     All      |          |  -      |![C8EB9F45-890E-48FD-A511-02A54360DC47_4_5005_c](https://user-images.githubusercontent.com/12781303/99870875-e77cac00-2c08-11eb-9289-59cce6a14705.jpeg)|
|             U31                   |     All      |          |  -      |![B27F5BFC-0ECE-4ED2-BA0A-1AC3F05C7C1D_4_5005_c](https://user-images.githubusercontent.com/12781303/99870880-efd4e700-2c08-11eb-8f51-c96c363d5441.jpeg)|
|             U32                   |     All      |          |  -      |![36752537-B39C-40EA-B972-DD1DE444C82F_4_5005_c](https://user-images.githubusercontent.com/12781303/99870886-f8c5b880-2c08-11eb-98fd-4f926ee0dbeb.jpeg)|
|             U33                   |     All      |          |  -      |![5AAB5B3E-E3D5-4718-A5CE-8F8BFF4217B6_4_5005_c](https://user-images.githubusercontent.com/12781303/99870888-00855d00-2c09-11eb-921c-ea3a1073ef93.jpeg)|
|             U34                   |     All      |          |  -      |![323E849F-E346-4977-ABCC-8248E5713565_4_5005_c](https://user-images.githubusercontent.com/12781303/99870905-18f57780-2c09-11eb-9c9c-e19896f6c69c.jpeg)|
|             U35                   |     All      |          |  -      |![6B936E64-09BA-4C31-87AB-CFDB710A370F_4_5005_c](https://user-images.githubusercontent.com/12781303/99870909-201c8580-2c09-11eb-80c6-1c2d19f4a61e.jpeg)|
|             U36                   |     All      |          |  -      |![1D118C25-BAE8-467E-8F63-AA1F1F097A9C_4_5005_c](https://user-images.githubusercontent.com/12781303/99870915-2a3e8400-2c09-11eb-9120-73fd5ce9e4bf.jpeg)|
|             U37                   |     All      |          |  -      |![5593ADAF-4734-4674-80A9-D0AD802EDDDB_4_5005_c](https://user-images.githubusercontent.com/12781303/99870918-30346500-2c09-11eb-80e6-d0fc93cb5fd0.jpeg)|
|             U38                   |     All      |          |  -      |![2B8CFB58-736D-4C76-B921-9304DB29FCD5_4_5005_c](https://user-images.githubusercontent.com/12781303/99870921-34f91900-2c09-11eb-9e1d-3185f6e3de24.jpeg)|
|             U39                   |     All      |          |  -      |![CAC95B99-6EB7-428D-9F01-0540269F7347_4_5005_c](https://user-images.githubusercontent.com/12781303/99870927-3b879080-2c09-11eb-9c00-7ff2ede8b4b6.jpeg)|
|             U40                   |     All      |          |  -      |![1E85F24E-DBF9-4505-805A-C5A5BD6DB14A_4_5005_c](https://user-images.githubusercontent.com/12781303/99870931-417d7180-2c09-11eb-9039-9effba7d65d1.jpeg)|
|             U41                   |     All      |          |  -      |![6C786442-8D56-42F5-9679-65C4582C7E66_4_5005_c](https://user-images.githubusercontent.com/12781303/99870934-49d5ac80-2c09-11eb-82da-eed5a41a9697.jpeg)|
|             U42                   |     All      |          |  -      |![28A435A1-C10F-4A66-B5DA-7EE913303225_4_5005_c](https://user-images.githubusercontent.com/12781303/99870938-4fcb8d80-2c09-11eb-8d3b-4e97bb48e46d.jpeg)|
|             U43                   |     All      |          |  -      |![561662D0-39EC-40CB-BBE4-2A89D13B97B3_4_5005_c](https://user-images.githubusercontent.com/12781303/99870953-6a9e0200-2c09-11eb-9522-a7f7dc73ef7f.jpeg)|
|             U44                   |     All      |          |  -      |![68159C31-E37F-4796-A639-B6DE1518EC26_4_5005_c](https://user-images.githubusercontent.com/12781303/99870956-738ed380-2c09-11eb-8d08-edb732154928.jpeg)|
|             U45                   |     All      |          |  -      |![EACCAF50-396C-4A8C-9364-6DBD7CAC7104_4_5005_c](https://user-images.githubusercontent.com/12781303/99870962-7db0d200-2c09-11eb-9092-2bd7d4901acb.jpeg)|
|             U46                   |     All      |          |  -      |![12CB5415-344B-4148-80C3-04C886E89F15_4_5005_c](https://user-images.githubusercontent.com/12781303/99870964-85707680-2c09-11eb-9b41-b56123156097.jpeg)|
|             U47                   |     All      |          |  -      |![9B95218E-94B0-4505-AF22-CE08EF8D3459_4_5005_c](https://user-images.githubusercontent.com/12781303/99870967-8c978480-2c09-11eb-8c24-fd3c66d82bde.jpeg)|
|             U48                   |     All      |          |  -      |![0A47837B-D3CF-401E-8D41-EE28C01A82A6_4_5005_c](https://user-images.githubusercontent.com/12781303/99870972-94572900-2c09-11eb-9b54-10843b0b26fd.jpeg)|
|             U49                   |     All      |          |  -      |![6316565E-F595-4844-A090-54A8625132A7_4_5005_c](https://user-images.githubusercontent.com/12781303/99870973-9b7e3700-2c09-11eb-897e-195d8667582f.jpeg)|
|             U50                   |     All      |          |  -      |![6923958B-4DE5-4972-8440-56A7F5234B8C_4_5005_c](https://user-images.githubusercontent.com/12781303/99870976-a20cae80-2c09-11eb-83e9-b0b752acae6a.jpeg)|
|             U51                   |     All      |          |  -      |![61B8583D-8716-4023-9C1B-899643507B0C_4_5005_c](https://user-images.githubusercontent.com/12781303/99870981-ab961680-2c09-11eb-96a3-9772417e0f12.jpeg)|
|             U52                   |     All      |          |  -      |![030D3A9C-C956-4F2A-8AE3-69657E0DF8CE_4_5005_c](https://user-images.githubusercontent.com/12781303/99870984-b3ee5180-2c09-11eb-87e5-fe28d9cca9cc.jpeg)|
|             U53                   |     All      |          |  -      |![66102C51-05E6-4DDF-962B-D2EFA94DAD75_4_5005_c](https://user-images.githubusercontent.com/12781303/99870989-ba7cc900-2c09-11eb-8000-4fe22c4743ee.jpeg)|
|             U54                   |     All      |          |  -      |![5F2704F1-1161-4958-96F7-6432C34AF824_4_5005_c](https://user-images.githubusercontent.com/12781303/99870993-c10b4080-2c09-11eb-88d4-761aca000063.jpeg)|
|             U55                   |     All      |          |  -      |![D41E1302-B665-4719-8D41-4CFCD567E5D3_4_5005_c](https://user-images.githubusercontent.com/12781303/99870995-c6688b00-2c09-11eb-8661-7d78c9319f27.jpeg)|
|             U56                   |     All      |          |  -      |![4A3E87EA-237D-4ECF-B779-4C280B16C5F2_4_5005_c](https://user-images.githubusercontent.com/12781303/99870998-cd8f9900-2c09-11eb-9b64-9b19f3c58ec0.jpeg)|
|             U57                   |     All      |          |  -      |![547FFEC6-30E6-4CF1-B738-EA96D997E349_4_5005_c](https://user-images.githubusercontent.com/12781303/99871009-e39d5980-2c09-11eb-8886-82d1a67ee8d5.jpeg)|
|             U58                   |     All      |          |  -      |![A4FDB210-684E-4781-B584-F979CF56B8BF_4_5005_c](https://user-images.githubusercontent.com/12781303/99871012-eb5cfe00-2c09-11eb-9ec2-956bf3c94b24.jpeg)|
|             U59                   |     All      |          |  -      |![C4E8CAF3-8F80-43BD-84F5-C3434AB7164A_4_5005_c](https://user-images.githubusercontent.com/12781303/99871017-f152df00-2c09-11eb-8e34-cd4ccdebe311.jpeg)|
|             U60                   |     All      |          |  -      |![3B865279-0041-4E78-BF9E-24AF11C268E0_4_5005_c](https://user-images.githubusercontent.com/12781303/99871020-f748c000-2c09-11eb-82c1-863004b4c224.jpeg)|
|             U61                   |     All      |          |  -      |![2FEA658B-3436-4BFA-A056-D6B3997F9A97_4_5005_c](https://user-images.githubusercontent.com/12781303/99871021-fdd73780-2c09-11eb-9379-7bb73c3f7f97.jpeg)|
|             U62                   |     All      |          |  -      |![E3E7B54D-1AF3-4501-9917-34C6D41F431D_4_5005_c](https://user-images.githubusercontent.com/12781303/99871023-03348200-2c0a-11eb-963f-9e20afc082ee.jpeg)|
|             U63                   |     All      |          |  -      |![4A401992-E1AE-4E27-900D-699B12292285_4_5005_c](https://user-images.githubusercontent.com/12781303/99871030-0a5b9000-2c0a-11eb-8420-c9dd8b671046.jpeg)|
|             U64                   |     All      |          |  -      |![AB429BB0-C9AC-4A45-8E74-995DCB3708F2_4_5005_c](https://user-images.githubusercontent.com/12781303/99871034-10517100-2c0a-11eb-8a2c-4ba4ff0808e2.jpeg)|
|             U65                   |     All      |          |  -      |![090D1D1D-644C-42DB-A0DF-D298C44D2B7D_4_5005_c](https://user-images.githubusercontent.com/12781303/99871041-16dfe880-2c0a-11eb-9da5-7ca3176da7b5.jpeg)|
|             U66                   |     All      |          |  -      |![1FF98974-6752-415B-8DF9-41F5376060CF_4_5005_c](https://user-images.githubusercontent.com/12781303/99871049-1e9f8d00-2c0a-11eb-8b37-156c8597f833.jpeg)|
|             U67                   |     All      |          |  -      |![3DC4C28B-F80B-4796-83B9-FC9DC69394BB_4_5005_c](https://user-images.githubusercontent.com/12781303/99871052-252e0480-2c0a-11eb-8323-3b09225fcef2.jpeg)|
|             U68                   |     All      |          |  -      |![164041FA-6F1B-478B-A0EF-31B7755ED483_4_5005_c](https://user-images.githubusercontent.com/12781303/99871083-5c9cb100-2c0a-11eb-8e75-762fe881e168.jpeg)|
|             U69                   |     All      |          |  -      |![EF538106-D9AA-4C44-86ED-B96550B39B56_4_5005_c](https://user-images.githubusercontent.com/12781303/99871090-63c3bf00-2c0a-11eb-8ce8-4bb526d90f44.jpeg)|
|             U70                   |     All      |          |  -      |![B9A79064-356E-4CF0-8CB8-7BCAC844BF7D_4_5005_c](https://user-images.githubusercontent.com/12781303/99871091-69b9a000-2c0a-11eb-9c10-fd6c48732f92.jpeg)|
|             U71                   |     All      |          |  -      |![5CF63259-B379-4231-A1A3-D104B9D2806D_4_5005_c](https://user-images.githubusercontent.com/12781303/99871106-8655d800-2c0a-11eb-82b7-4ac0c3153e44.jpeg)|
|             U72                   |     All      |          |  -      |![2394D768-EDCA-4008-B32D-8194AA983DDD_4_5005_c](https://user-images.githubusercontent.com/12781303/99871111-8d7ce600-2c0a-11eb-921e-d35c770db76e.jpeg)|
|             U73                   |     All      |          |  -      |![B352597C-8885-4381-9107-B99504885419_4_5005_c](https://user-images.githubusercontent.com/12781303/99871115-940b5d80-2c0a-11eb-9a0e-f8c58d87c9d5.jpeg)|
|             U74                   |     All      |          |  -      |![AEC2DD54-44AD-42B8-A0DD-954EC26EC6CA_4_5005_c](https://user-images.githubusercontent.com/12781303/99871120-9a99d500-2c0a-11eb-91b4-e6469add8f7a.jpeg)|
|             U75                   |     All      |          |  -      |![9D11F67F-D265-432F-BC08-D67020D48FDF_4_5005_c](https://user-images.githubusercontent.com/12781303/99871123-9ff71f80-2c0a-11eb-9d57-4d146cd06159.jpeg)|
|             U76                   |     All      |          |  -      |![278EC8B8-1600-4D81-A9BF-BE91DFDDBB6D_4_5005_c](https://user-images.githubusercontent.com/12781303/99871126-a5546a00-2c0a-11eb-98f8-17732e456062.jpeg)|
|             U77                   |     All      |          |  -      |![68370EAD-5820-4975-BA38-E08F7EC363AE_4_5005_c](https://user-images.githubusercontent.com/12781303/99871128-abe2e180-2c0a-11eb-9540-6e60b5d6dedc.jpeg)|
|             U78                   |     All      |          |  -      |![905E05D1-580C-4C2D-9A29-CDF757F007E9_4_5005_c](https://user-images.githubusercontent.com/12781303/99871134-b1402c00-2c0a-11eb-96b8-76a3926120e0.jpeg)|
|             U79                   |     All      |          |  -      |![721C5542-0156-4CF9-BB8D-6C0DD3D0E7A7_4_5005_c](https://user-images.githubusercontent.com/12781303/99871136-b7cea380-2c0a-11eb-8349-8a17aae118ee.jpeg)|
|             U80                   |     All      |          |  -      |![24BE0412-6A60-424A-A6F0-97D4D90B13F4_4_5005_c](https://user-images.githubusercontent.com/12781303/99871140-bdc48480-2c0a-11eb-8a2f-029dd4b9cba6.jpeg)|
|             U81                   |     All      |          |  -      |![40A5F433-AD4B-4F94-B4D9-910C1515FA2B_4_5005_c](https://user-images.githubusercontent.com/12781303/99871142-c452fc00-2c0a-11eb-8cfd-8be57937d595.jpeg)|
|             U82                   |     All      |          |  -      |![C990D380-B5D2-446F-8F69-DE37C25D5433_4_5005_c](https://user-images.githubusercontent.com/12781303/99871143-cae17380-2c0a-11eb-8861-89aadb018cc2.jpeg)|
|             U83                   |     All      |          |  -      |![F43E5A1C-C9DA-447E-BF84-2349822C71B1_4_5005_c](https://user-images.githubusercontent.com/12781303/99871147-d03ebe00-2c0a-11eb-890f-71e3a26ac344.jpeg)|
|             U84                   |     All      |          |  -      |![002E3540-4FB8-4E53-89F3-6EFC511C7E2E_4_5005_c](https://user-images.githubusercontent.com/12781303/99871152-d6cd3580-2c0a-11eb-89c7-69d2b83873af.jpeg)|
|             U85                   |     All      |          |  -      |![ED9B7911-3386-4954-A113-39F041EE72C7_4_5005_c](https://user-images.githubusercontent.com/12781303/99871155-db91e980-2c0a-11eb-9961-d664c8e9f87a.jpeg)|
|             U86                   |     All      |          |  -      |![D7F3477E-438A-43F9-8CA3-0B308247C790_4_5005_c](https://user-images.githubusercontent.com/12781303/99871162-e187ca80-2c0a-11eb-8782-185206d7943e.jpeg)|
|             U87                   |     All      |          |  -      |![13A22170-6B96-4C5B-BD4B-CF9BCB2E2A3E_4_5005_c](https://user-images.githubusercontent.com/12781303/99871178-f6645e00-2c0a-11eb-8827-6fe4bc529217.jpeg)|
|             U88                   |     All      |          |  -      |![99B96C42-33E7-4CC8-95F5-0E9C6985A03C_4_5005_c](https://user-images.githubusercontent.com/12781303/99871180-fcf2d580-2c0a-11eb-95d5-9fc20c6f5902.jpeg)|
|             U89                   |     All      |          |  -      |![59E8C853-5895-47C6-AF67-2BAB8D6C4D0C_4_5005_c](https://user-images.githubusercontent.com/12781303/99871186-0419e380-2c0b-11eb-9435-9a108bda27ba.jpeg)|
|             U90                   |     All      |          |  -      |![52062485-20F7-4323-AF54-0F3BE58B5C56_4_5005_c](https://user-images.githubusercontent.com/12781303/99871190-0c721e80-2c0b-11eb-8d6a-8c38974ae816.jpeg)|
|             U91                   |     All      |          |  -      |![7052AA3F-F993-4580-B334-0711A2C05D65_4_5005_c](https://user-images.githubusercontent.com/12781303/99871203-20b61b80-2c0b-11eb-9210-50b492710c9c.jpeg)|
|             U92                   |     All      |          |  -      |![B5418F84-B540-4EC6-9D7C-367A7564722F_4_5005_c](https://user-images.githubusercontent.com/12781303/99871205-27449300-2c0b-11eb-903e-f385236835b7.jpeg)|
|             U93                   |     All      |          |  -      |![1953572C-B2B7-4CEE-9A2A-92D0B86BEC43_4_5005_c](https://user-images.githubusercontent.com/12781303/99871209-2e6ba100-2c0b-11eb-94ad-379b799e32df.jpeg)|
|             U94                   |     All      |          |  -      |![48186860-D425-4B45-AA6F-FC651232A59E_4_5005_c](https://user-images.githubusercontent.com/12781303/99871218-36c3dc00-2c0b-11eb-8b0e-347a7b321b6c.jpeg)|
|             U95                   |     All      |          |  -      |![753AF121-1D1D-44D3-BFBB-E04DBB8BB5EA_4_5005_c](https://user-images.githubusercontent.com/12781303/99871222-3d525380-2c0b-11eb-9b09-53c42570545e.jpeg)|
|             U96                   |     All      |          |  -      |![E9E6C003-5D0D-4D40-9A18-AA316FEA0A31_4_5005_c](https://user-images.githubusercontent.com/12781303/99871225-417e7100-2c0b-11eb-96b2-7cdef9c7d7bf.jpeg)|
|             U97                   |     All      |          |  -      |![615AFBF3-BBD4-4222-8A3F-1B521B8C378B_4_5005_c](https://user-images.githubusercontent.com/12781303/99871237-607d0300-2c0b-11eb-95d3-320b33641b97.jpeg)|
|             U98                   |     All      |          |  -      |![54170256-754A-4E6E-A188-8DA106EEAD23_4_5005_c](https://user-images.githubusercontent.com/12781303/99871241-6672e400-2c0b-11eb-8644-00a07e43e6c5.jpeg)|
|             U99                   |     All      |          |  -      |![56447B2A-C547-47F8-BC49-0B8D7D732BDC_4_5005_c](https://user-images.githubusercontent.com/12781303/99871245-6a9f0180-2c0b-11eb-84ae-e24fa864d180.jpeg)|
|             U100                   |     All      |          |  -      |![212E144C-75C5-43B6-9507-042D49101CCD_4_5005_c](https://user-images.githubusercontent.com/12781303/99871251-7094e280-2c0b-11eb-9639-61bccbe53dae.jpeg)|
|             U101                   |     All      |          |  -      |![F5129C63-D7AB-4F98-9962-918C907C9A7E_4_5005_c](https://user-images.githubusercontent.com/12781303/99871257-75f22d00-2c0b-11eb-93d9-b1ca93f1a041.jpeg)|
|             U102                   |     All      |          |  -      |![2F494C32-3D7B-4E44-8991-7730B7A0A41A_4_5005_c](https://user-images.githubusercontent.com/12781303/99871259-7be80e00-2c0b-11eb-8150-71c529a9162b.jpeg)|
|             U103                   |     All      |          |  -      |![5CF1E01E-B469-4768-A769-35307CF8555F_4_5005_c](https://user-images.githubusercontent.com/12781303/99871261-80acc200-2c0b-11eb-86e6-9efe742829fe.jpeg)|
|             U104                   |     All      |          |  -      |![48EB11C0-80C2-4358-AE6B-33FE76FDDE69_4_5005_c](https://user-images.githubusercontent.com/12781303/99871275-873b3980-2c0b-11eb-939a-8383883cc8fb.jpeg)|
|             U105                   |     All      |          |  -      |![188D525A-0417-4292-BFBA-3C18FAB0C151_4_5005_c](https://user-images.githubusercontent.com/12781303/99871276-8c988400-2c0b-11eb-8d50-f84e5d4768c3.jpeg)|
|             U106                   |     All      |          |  -      |![761EFDF3-EDBD-4582-ABB4-F197DFCB2446_4_5005_c](https://user-images.githubusercontent.com/12781303/99871278-928e6500-2c0b-11eb-8abe-4ae2495b203b.jpeg)|
|             U107                   |     All      |          |  -      |![bee_nest_front_honey](https://user-images.githubusercontent.com/12781303/100518006-7cf7dd00-31c1-11eb-90c6-3ddb5a2cfce7.png)|
|             U108                   |     All      |          |  -      |![beehive_front_honey](https://user-images.githubusercontent.com/12781303/100518031-a3b61380-31c1-11eb-8c2b-3213d49b4155.png)|
|             U109                   |     All      |          |  -      |![acacia_sign](https://user-images.githubusercontent.com/12781303/100518048-bc262e00-31c1-11eb-8c75-cbefc4abb1cf.png)|
|             U110                   |     All      |          |  -      |![small](https://user-images.githubusercontent.com/12781303/100518067-d8c26600-31c1-11eb-89a2-a4a2c8c55960.png)|
|             U111                   |     All      |          |  -      |![bell_item](https://user-images.githubusercontent.com/12781303/100518081-e972dc00-31c1-11eb-92d1-b0c86b43d033.png)|
|             U112                   |     All      |          |  -      |![beetroot_soup](https://user-images.githubusercontent.com/12781303/100518087-f7286180-31c1-11eb-8aef-851137c64e46.png)|
|             U113                   |     All      |          |  -      |![bamboo](https://user-images.githubusercontent.com/12781303/100518106-060f1400-31c2-11eb-9786-b0c5c7ec180b.png)|
|             U114                   |     All      |          |  -      |![book_and_quill](https://user-images.githubusercontent.com/12781303/100518114-145d3000-31c2-11eb-9740-c0434bd14cfd.png)|
|             U115                   |     All      |          |  -      |![book](https://user-images.githubusercontent.com/12781303/100518118-1c1cd480-31c2-11eb-90b9-30bf5ac282b1.png)|
|             U116                   |     All      |          |  -      |![black_dye](https://user-images.githubusercontent.com/12781303/100518126-3bb3fd00-31c2-11eb-96ee-e6bdc8f623a0.png)|
|             U117                   |     All      |          |  -      |![blue_dye](https://user-images.githubusercontent.com/12781303/100518127-3d7dc080-31c2-11eb-9536-a6d78158a30d.png)|
|             U118                   |     All      |          |  -      |![brown_dye](https://user-images.githubusercontent.com/12781303/100518138-58503500-31c2-11eb-959b-e27c3977177a.png)|
|             U119                   |     All      |          |  -      |![bundle](https://user-images.githubusercontent.com/12781303/100518144-64d48d80-31c2-11eb-94c6-aa69447685bd.png)|
|             U120                   |     All      |          |  -      |![campfire](https://user-images.githubusercontent.com/12781303/100518151-70c04f80-31c2-11eb-8634-1d41ed4ebdc1.png)|
|             U121                   |     All      |          |  -      |![coal](https://user-images.githubusercontent.com/12781303/100518160-7f0e6b80-31c2-11eb-9bd1-5e0a5820f40a.png)|
|             U122                   |     All      |          |  -      |![cooked_porkchop](https://user-images.githubusercontent.com/12781303/100518174-8f264b00-31c2-11eb-95d7-ffd18a1b9be9.png)|
|             U123                   |     All      |          |  -      |![diamond](https://user-images.githubusercontent.com/12781303/100518181-9b120d00-31c2-11eb-8098-6188c94a9ad8.png)|
|             U124                   |     All      |          |  -      |![elytra](https://user-images.githubusercontent.com/12781303/100518189-a49b7500-31c2-11eb-9474-5057def5a12e.png)|
|             U125                   |     All      |          |  -      |![emerald_blue](https://user-images.githubusercontent.com/12781303/100518193-b11fcd80-31c2-11eb-92c6-211f40af53d8.png)|
|             U126                   |     All      |          |  -      |![emerald_yellow](https://user-images.githubusercontent.com/12781303/100518197-b1b86400-31c2-11eb-8e2e-eca297f65bb3.png)|
|             U127                   |     All      |          |  -      |![emerald](https://user-images.githubusercontent.com/12781303/100518199-b2e99100-31c2-11eb-8652-076a85fefc06.png)|
|             U128                   |     All      |          |  -      |![enchanted_apple](https://user-images.githubusercontent.com/12781303/100518216-c72d8e00-31c2-11eb-9dcc-1e31210ab88e.png)|
|             U129                   |     All      |          |  -      |![ender_eye](https://user-images.githubusercontent.com/12781303/100518225-d7456d80-31c2-11eb-8577-8baf79e50414.png)|
|             U130                   |     All      |          |  -      |![ender_pearl](https://user-images.githubusercontent.com/12781303/100518230-df9da880-31c2-11eb-82cc-e6977023e8b4.png)|
|             U131                   |     All      |          |  -      |![experience_bottle](https://user-images.githubusercontent.com/12781303/100518269-225f8080-31c3-11eb-8272-383408a457f8.png)|
|             U132                   |     All      |          |  -      |![fire_charge](https://user-images.githubusercontent.com/12781303/100518271-24c1da80-31c3-11eb-9b9a-032d5d1e6b62.png)|
|             U133                   |     All      |          |  -      |![glass_bottle](https://user-images.githubusercontent.com/12781303/100518277-2ab7bb80-31c3-11eb-9d00-668f716c7bec.png)|
|             U134                   |     All      |          |  -      |![glowstone_dust](https://user-images.githubusercontent.com/12781303/100518280-2db2ac00-31c3-11eb-89b0-b54dec6eef24.png)|
|             U135                   |     All      |          |  -      |![gold_nugget](https://user-images.githubusercontent.com/12781303/100518284-31463300-31c3-11eb-9a83-b85a3e459b54.png)|
|             U136                   |     All      |          |  -      |![golden_helmet](https://user-images.githubusercontent.com/12781303/100518308-533fb580-31c3-11eb-89dd-5d6bca1a5a81.png)|
|             U137                   |     All      |          |  -      |![green_dye](https://user-images.githubusercontent.com/12781303/100518310-55a20f80-31c3-11eb-9435-9046e11260f2.png)|
|             U138                   |     All      |          |  -      |![honey_bottle](https://user-images.githubusercontent.com/12781303/100518311-589d0000-31c3-11eb-9886-49d2a5eff60d.png)|
|             U139                   |     All      |          |  -      |![iron_nugget](https://user-images.githubusercontent.com/12781303/100518315-5b97f080-31c3-11eb-8305-b553b39bfea2.png)|
|             U140                   |     All      |          |  -      |![lantern](https://user-images.githubusercontent.com/12781303/100518336-779b9200-31c3-11eb-98aa-42589c2b32f4.png)|
|             U141                   |     All      |          |  -      |![light_blue_dye](https://user-images.githubusercontent.com/12781303/100518339-7d917300-31c3-11eb-85ba-95b849b72488.png)|
|             U142                   |     All      |          |  -      |![light_gray_dye](https://user-images.githubusercontent.com/12781303/100518341-7f5b3680-31c3-11eb-8de3-1a57ff655bd0.png)|
|             U143                   |     All      |          |  -      |![magma_cream](https://user-images.githubusercontent.com/12781303/100518343-81bd9080-31c3-11eb-99c7-803f896e3ee0.png)|
|             U144                   |     All      |          |  -      |![shield](https://user-images.githubusercontent.com/12781303/100518451-22ac4b80-31c4-11eb-9c7d-ab2e09eb27d6.png)|
|             U145                   |     All      |          |  -      |![shears](https://user-images.githubusercontent.com/12781303/100518453-24760f00-31c4-11eb-802d-066070464644.png)|
|             U146                   |     All      |          |  -      |![slime_ball](https://user-images.githubusercontent.com/12781303/100518454-2770ff80-31c4-11eb-811a-2eaa070b36dc.png)|
|             U147                   |     All      |          |  -      |![soul_torch_item](https://user-images.githubusercontent.com/12781303/100518456-2a6bf000-31c4-11eb-87be-3a69abcdfa38.png)|
|             U148                   |     All      |          |  -      |![torch_item](https://user-images.githubusercontent.com/12781303/100518460-2e980d80-31c4-11eb-97f7-dadae6299984.png)|
|             U149                   |     All      |          |  -      |![!!lfsfa](https://user-images.githubusercontent.com/12781303/101279047-0dea3c00-37f2-11eb-8fbf-f3f47e58e1e3.png)|
|             U150                   |     All      |          |  -      |![!emerald_block2](https://user-images.githubusercontent.com/12781303/101279053-193d6780-37f2-11eb-9a34-7c3de066cf70.png)|
|             U151                   |     All      |          |  -      |![crystal_block_lightning](https://user-images.githubusercontent.com/12781303/101279143-d3cd6a00-37f2-11eb-87e0-b72682b28bce.png)|
|             U152                   |     All      |          |  -      |![crystal_block_earth](https://user-images.githubusercontent.com/12781303/101279151-ddef6880-37f2-11eb-95a0-ef31f028adcd.png)|
|             U153                   |     All      |          |  -      |![crystal_block_fire](https://user-images.githubusercontent.com/12781303/101279157-e8a9fd80-37f2-11eb-9166-618321a25ce0.png)|
|             U154                   |     All      |          |  -      |![crystal_block_healing](https://user-images.githubusercontent.com/12781303/101279166-f19acf00-37f2-11eb-9c6c-ce8a96ede7dd.png)|
|             U155                   |     All      |          |  -      |![crystal_block_ice](https://user-images.githubusercontent.com/12781303/101279170-f9f30a00-37f2-11eb-8080-3bfd606b320f.png)|
|             U156                   |     All      |          |  -      |![crystal_block_necromancy](https://user-images.githubusercontent.com/12781303/101279176-05463580-37f3-11eb-999b-575f71d6ddec.png)|
|             U157                   |     All      |          |  -      |![crystal_block_sorcery](https://user-images.githubusercontent.com/12781303/101279180-0d05da00-37f3-11eb-8def-fe71c893996a.png)|
|             U158                   |     All      |          |  -      |![crystal_block](https://user-images.githubusercontent.com/12781303/101279188-1b53f600-37f3-11eb-961b-9d5aabd05154.png)|
|             U159                   |     All      |          |  -      |![crystal_earth](https://user-images.githubusercontent.com/12781303/101279191-23139a80-37f3-11eb-9e2c-95e2f8bf21f3.png)|
|             U160                   |     All      |          |  -      |![armour_upgrade](https://user-images.githubusercontent.com/12781303/101279206-3aeb1e80-37f3-11eb-8c2c-71d26a44c684.png)|
|             U161                   |     All      |          |  -      |![astral_diamond](https://user-images.githubusercontent.com/12781303/101279219-548c6600-37f3-11eb-9ef0-b2234279a187.png)|
|             U162                   |     All      |          |  -      |![cake_rice](https://user-images.githubusercontent.com/12781303/101279222-5bb37400-37f3-11eb-8e80-070cf0912ba3.png)|
|             U163                   |     All      |          |  -      |![crystal_fire](https://user-images.githubusercontent.com/12781303/101279228-65d57280-37f3-11eb-9406-5a47c0813c3b.png)|
|             U164                   |     All      |          |  -      |![crystal_flower](https://user-images.githubusercontent.com/12781303/101279235-71289e00-37f3-11eb-94eb-1b1e55203e18.png)|
|             U165                   |     All      |          |  -      |![crystal_grand](https://user-images.githubusercontent.com/12781303/101279240-800f5080-37f3-11eb-9a95-b5ed0c51532c.png)|
|             U166                   |     All      |          |  -      |![crystal_magic](https://user-images.githubusercontent.com/12781303/101279247-8ef60300-37f3-11eb-8efc-b209fcdb2bf5.png)|
|             U167                   |     All      |          |  -      |![crystal_ore](https://user-images.githubusercontent.com/12781303/101279251-95847a80-37f3-11eb-93fe-6eb1a5643746.png)|
|             U168                   |     All      |          |  -      |![curse_of_enfeeblement](https://user-images.githubusercontent.com/12781303/101279260-a2a16980-37f3-11eb-8ad2-7f80b6b2add3.png)|
|             U169                   |     All      |          |  -      |![diamond_block](https://user-images.githubusercontent.com/12781303/101279265-ab923b00-37f3-11eb-8807-9d18d1ccf56e.png)|
|             U170                   |     All      |          |  -      |![emerald_block](https://user-images.githubusercontent.com/12781303/101279280-c1076500-37f3-11eb-954a-0999d4df1a50.png)|
|             U171                   |     All      |          |  -      |![firebomb](https://user-images.githubusercontent.com/12781303/101279287-ca90cd00-37f3-11eb-82fd-a5cef3327053.png)|
|             U172                   |     All      |          |  -      |![gift](https://user-images.githubusercontent.com/12781303/101279292-d3819e80-37f3-11eb-97ed-915671baf643.png)|
|             U173                   |     All      |          |  -      |![hazelnutchocolateitem](https://user-images.githubusercontent.com/12781303/101279297-da101600-37f3-11eb-891f-d6e72615ad56.png)|
|             U174                   |     All      |          |  -      |![mana_flask_large](https://user-images.githubusercontent.com/12781303/101279301-ebf1b900-37f3-11eb-92c7-e5ae0b06ff1a.png)|
|             U175                   |     All      |          |  -      |![obsidian_crust_2](https://user-images.githubusercontent.com/12781303/101279304-f57b2100-37f3-11eb-9932-42d689717d8b.png)|
|             U176                   |     All      |          |  -      |![popped_chorus_fruit](https://user-images.githubusercontent.com/12781303/101279307-fdd35c00-37f3-11eb-97d4-7ca1c084c75d.png)|
|             U177                   |     All      |          |  -      |![poison_bomb](https://user-images.githubusercontent.com/12781303/101279311-09268780-37f4-11eb-8a6e-402da6dbc140.png)|
|             U178                   |     All      |          |  -      |![soup_rice](https://user-images.githubusercontent.com/12781303/101279322-1d6a8480-37f4-11eb-8581-13ce008d7583.png)|
|             U179                   |     All      |          |  -      |![spectral_dust_earth](https://user-images.githubusercontent.com/12781303/101279418-b39eaa80-37f4-11eb-9d53-bdae641aa847.png)|
|             U180                   |     All      |          |  -      |![spectral_dust_fire](https://user-images.githubusercontent.com/12781303/101279419-b5686e00-37f4-11eb-85ed-0c5eeaf18165.png)|
|             U181                   |     All      |          |  -      |![spectral_dust_healing](https://user-images.githubusercontent.com/12781303/101279420-b6010480-37f4-11eb-80d4-96ae152d1acc.png)|
|             U182                   |     All      |          |  -      |![spectral_dust_ice](https://user-images.githubusercontent.com/12781303/101279421-b6010480-37f4-11eb-831c-4d579d25a8cf.png)|
|             U183                   |     All      |          |  -      |![spectral_dust_lightning](https://user-images.githubusercontent.com/12781303/101279423-b6999b00-37f4-11eb-89df-cdd516a5ea0a.png)|
|             U184                   |     All      |          |  -      |![spectral_dust_necromancy](https://user-images.githubusercontent.com/12781303/101279424-b7323180-37f4-11eb-8ddb-dfdb6dbeb3a5.png)|
|             U185                   |     All      |          |  -      |![spectral_dust_sorcery](https://user-images.githubusercontent.com/12781303/101279425-b7323180-37f4-11eb-9d39-022baa19baf5.png)|
|             U186                   |     All      |          |  -      |![spell_book_festive](https://user-images.githubusercontent.com/12781303/101279454-f1033800-37f4-11eb-9c67-31c589f59309.png)|
|             U187                   |     All      |          |  -      |![stew_fish](https://user-images.githubusercontent.com/12781303/101279460-05473500-37f5-11eb-8b5c-c2eab742e966.png)|
|             U188                   |     All      |          |  -      |![stew_mountain](https://user-images.githubusercontent.com/12781303/101279461-06786200-37f5-11eb-9daa-b29580bfe10a.png)|
|             U189                   |     All      |          |  -      |![stew_pumpkin](https://user-images.githubusercontent.com/12781303/101279462-06786200-37f5-11eb-9549-2deb152fe37d.png)|
|             U190                   |     All      |          |  -      |![wand_festive](https://user-images.githubusercontent.com/12781303/101279468-1bed8c00-37f5-11eb-8b30-dae0ff79d97a.png)|
|             U191                   |     All      |          |  -      |![wand_master_fire](https://user-images.githubusercontent.com/12781303/101279471-1db74f80-37f5-11eb-9243-c7aff6ef474b.png)|
|             U192                   |     All      |          |  -      |![wizard_hat_earth](https://user-images.githubusercontent.com/12781303/101279481-3293e300-37f5-11eb-8d24-c0f4f4de378a.png)|
|             U193                   |     All      |          |  -      |![wizard_hat_fire](https://user-images.githubusercontent.com/12781303/101279482-33c51000-37f5-11eb-891d-6217409c4c39.png)|
|             U194                   |     All      |          |  -      |![wizard_hat_healing](https://user-images.githubusercontent.com/12781303/101279483-345da680-37f5-11eb-9b22-55bc629ec455.png)|
|             U195                   |     All      |          |  -      |![wizard_hat_necromancy](https://user-images.githubusercontent.com/12781303/101279484-34f63d00-37f5-11eb-845d-456301f25680.png)|
|             U196                   |     All      |          |  -      |![wizard_hat_sorcery](https://user-images.githubusercontent.com/12781303/101279485-34f63d00-37f5-11eb-8847-df5e09bdf9c0.png)|
|             U197                   |     All      |          |  -      |![worm](https://user-images.githubusercontent.com/12781303/101279500-4fc8b180-37f5-11eb-9fdd-ba6fdc15cf7c.png)|
|             U198                   |     All      |          |  -      |![wand_architect](https://user-images.githubusercontent.com/12781303/101279503-52c3a200-37f5-11eb-8f34-1639bda9c674.png)|
|             U199                   |     All      |          |  -      |![vishroom](https://user-images.githubusercontent.com/12781303/101279505-53f4cf00-37f5-11eb-89bd-c2700b690a97.png)|
|             U200                   |     All      |          |  -      |![treasure_chest](https://user-images.githubusercontent.com/12781303/101279509-56572900-37f5-11eb-899d-38d4b967f765.png)|
|             U201                   |     All      |          |  -      |![tin_can](https://user-images.githubusercontent.com/12781303/101280279-d6cc5880-37fa-11eb-9eae-cbaba8de9202.png)|
|             U202                   |     All      |          |  -      |![starshell_turtle](https://user-images.githubusercontent.com/12781303/101279532-7c7cc900-37f5-11eb-9df1-818a474e753f.png)|
|             U203                   |     All      |          |  -      |![box_turtle](https://user-images.githubusercontent.com/12781303/101279542-83a3d700-37f5-11eb-94c1-dc49788e838e.png)|
|             U204                   |     All      |          |  -      |![brass_gear](https://user-images.githubusercontent.com/12781303/101279543-86063100-37f5-11eb-899e-6d68e83083a0.png)|
|             U205                   |     All      |          |  -      |![carminite_block](https://user-images.githubusercontent.com/12781303/101279546-88688b00-37f5-11eb-984e-ce8587bb95f1.png)|
|             U206                   |     All      |          |  -      |![arapaima](https://user-images.githubusercontent.com/12781303/101279587-ccf42680-37f5-11eb-8f10-e7cbf655bf14.png)|
|             U207                   |     All      |          |  -      |![atlantic_cod](https://user-images.githubusercontent.com/12781303/101279588-cebdea00-37f5-11eb-8802-33462a032bc3.png)|
|             U208                   |     All      |          |  -      |![atlantic_herring](https://user-images.githubusercontent.com/12781303/101279590-d1204400-37f5-11eb-904e-4d0e1e4978e1.png)|
|             U209                   |     All      |          |  -      |![blackfish](https://user-images.githubusercontent.com/12781303/101279592-d2ea0780-37f5-11eb-9c51-7c66dec7e0f6.png)|
|             U210                   |     All      |          |  -      |![bluegill](https://user-images.githubusercontent.com/12781303/101279593-d4b3cb00-37f5-11eb-8a2e-53792ef99a8c.png)|
|             U211                   |     All      |          |  -      |![brown_shrooma](https://user-images.githubusercontent.com/12781303/101279595-d7162500-37f5-11eb-947e-a960a08ce72b.png)|
|             U212                   |     All      |          |  -      |![capitaine](https://user-images.githubusercontent.com/12781303/101279596-d9787f00-37f5-11eb-882b-ccb1ba4fdc46.png)|
|             U213                   |     All      |          |  -      |![firefly](https://user-images.githubusercontent.com/12781303/101279617-02990f80-37f6-11eb-8df5-2c0f28c6c95f.png)|
|             U214                   |     All      |          |  -      |![fish_bones](https://user-images.githubusercontent.com/12781303/101279621-09c01d80-37f6-11eb-81b2-1eeb6ff75bf8.png)|
|             U215                   |     All      |          |  -      |![frog](https://user-images.githubusercontent.com/12781303/101279627-16447600-37f6-11eb-9239-8a08e13628e1.png)|
|             U216                   |     All      |          |  -      |![jellyfish](https://user-images.githubusercontent.com/12781303/101279630-193f6680-37f6-11eb-9b5b-abd6dda0ab83.png)|
|             U217                   |     All      |          |  -      |![muskellunge](https://user-images.githubusercontent.com/12781303/101279639-2a887300-37f6-11eb-9f79-b51d6747eb05.png)|
|             U218                   |     All      |          |  -      |![message_in_a_bottle](https://user-images.githubusercontent.com/12781303/101279641-2c523680-37f6-11eb-9c49-7b73f4e79aa1.png)|
|             U219                   |     All      |          |  -      |![smallmouth_bass](https://user-images.githubusercontent.com/12781303/101279644-2f4d2700-37f6-11eb-8bf2-4bc2f72e8bdb.png)|
|             U220                   |     All      |          |  -      |![red_shrooma](https://user-images.githubusercontent.com/12781303/101279648-307e5400-37f6-11eb-80af-b702dc7bed6d.png)|
|             U221                   |     All      |          |  -      |![ur_ghast_trophy](https://user-images.githubusercontent.com/12781303/101279654-35430800-37f6-11eb-9924-2d28a4903809.png)|
|             U222                   |     All      |          |  -      |![snow_queen_trophy](https://user-images.githubusercontent.com/12781303/101279657-396f2580-37f6-11eb-9fac-5220977928b8.png)|
|             U223                   |     All      |          |  -      |![naga_trophy](https://user-images.githubusercontent.com/12781303/101279661-3ecc7000-37f6-11eb-9e22-7ac7d3ca04d6.png)|
|             U224                   |     All      |          |  -      |![lich_trophy](https://user-images.githubusercontent.com/12781303/101279662-3ffd9d00-37f6-11eb-92af-f9aabbefa4ac.png)|
|             U225                   |     All      |          |  -      |![hydra_trophy](https://user-images.githubusercontent.com/12781303/101279663-41c76080-37f6-11eb-8cca-1ca724f7e4fd.png)|
|             U2A01                  |     All      |          |  -      |![tส้่fาrfrfffhxffgdfgftrgยcfggvtfgtgffย](https://user-images.githubusercontent.com/12781303/103541199-a5b07800-4ecd-11eb-8c24-4b16296f34c9.png)|
|             U2A02                  |     All      |          |  -      |![tส้่fาrfrfffhxffgdfgftrgยfggvtfgtgffย](https://user-images.githubusercontent.com/12781303/103541243-c082ec80-4ecd-11eb-9a9e-f7a4990a48f8.png)|
|             U2A03                  |     All      |          |  -      |![tส้่fาrfrfffhxffgdfgftrgยfggvtgtgffย](https://user-images.githubusercontent.com/12781303/103541248-c24cb000-4ecd-11eb-9dac-f426242cf6ad.png)|
|             U2A04                  |     All      |          |  -      |![tส้่fาrfrfffxffgdfgftrgยfggvtgtgffย](https://user-images.githubusercontent.com/12781303/103541252-c37ddd00-4ecd-11eb-9e7d-97dea9d8fb71.png)|
|             U2A05                  |     All      |          |  -      |![tส้่fาrfrvfffhxffgdfgftrgยcfggvtfgtgffย](https://user-images.githubusercontent.com/12781303/103541262-c5e03700-4ecd-11eb-9840-dad4dc34425a.png)|
|             U2A06                  |     All      |          |  -      |![tส้่fาrvfrvfffhxffgdfgftrgยcfggvtfgtgffย](https://user-images.githubusercontent.com/12781303/103541269-c7a9fa80-4ecd-11eb-934c-08d178a0c27c.png)|
|             U2A07                  |     All      |          |  -      |![tส้่fาrvfrvvfffhxffgdfgftrgยcfggvtfgtgffย](https://user-images.githubusercontent.com/12781303/103541272-c973be00-4ecd-11eb-8439-bf4e87cbf49f.png)|
|             U2A08                  |     All      |          |  -      |![tส้่fาrvfrvvvfffhxffgdfgftrgยcfggvtfgtgffย](https://user-images.githubusercontent.com/12781303/103541277-cbd61800-4ecd-11eb-9c42-4db5f6beee90.png)|
|             U2A09                  |     All      |          |  -      |![tส้่fาfffgdfgftrgยfgvtgtffย](https://user-images.githubusercontent.com/12781303/103541702-659dc500-4ece-11eb-8628-553751fa1a73.png)|
|             U2A10                  |     All      |          |  -      |![tส้่fาfffgfgftrgยfgtgtffย](https://user-images.githubusercontent.com/12781303/103541712-6898b580-4ece-11eb-86ed-39b72569e9d6.png)|
|             U2A11                  |     All      |          |  -      |![tส้่fาfffgfgftrgยfgvtgtffย](https://user-images.githubusercontent.com/12781303/103541718-6afb0f80-4ece-11eb-841f-9e32b7526d2a.png)|
|             U2A12                  |     All      |          |  -      |![tส้่fาrffffgdfgftrgยfgvtgtffย](https://user-images.githubusercontent.com/12781303/103541728-6cc4d300-4ece-11eb-835a-365bc0946318.png)|
|             U2A13                  |     All      |          |  -      |![tส้่fาrfffgdfgftrgยfgvtgtffย](https://user-images.githubusercontent.com/12781303/103541739-6e8e9680-4ece-11eb-8073-26a1194b4fc1.png)|
|             U2A14                  |     All      |          |  -      |![tส้่fาrrffffgdfgftrgยfgvtgtffย](https://user-images.githubusercontent.com/12781303/103541745-70585a00-4ece-11eb-8a2f-fb38eb57c8d4.png)|
|             U2A15                  |     All      |          |  -      |![tส้่fาrrfffxffgdfgftrgยfgvtgtffย](https://user-images.githubusercontent.com/12781303/103541752-72221d80-4ece-11eb-9c93-c9dff544ca17.png)|
|             U2A16                  |     All      |          |  -      |![tส้่fาrrffxffgdfgftrgยfgvtgtffย](https://user-images.githubusercontent.com/12781303/103541755-73ebe100-4ece-11eb-85b6-0ca5855e1649.png)|
|             U2A17                  |     All      |          |  -      |![!](https://user-images.githubusercontent.com/12781303/103541862-9e3d9e80-4ece-11eb-943e-d715908fefea.png)|
|             U2A18                  |     All      |          |  -      |![งง](https://user-images.githubusercontent.com/12781303/103541865-9f6ecb80-4ece-11eb-9a22-1b90826e63b1.png)|
|             U2A19                  |     All      |          |  -      |![คลิ๊กขวา](https://user-images.githubusercontent.com/12781303/103541867-a1388f00-4ece-11eb-8adf-468852ec9f51.png)|
|             U2A20                  |     All      |          |  -      |![คลิ๊กซ้าย](https://user-images.githubusercontent.com/12781303/103541872-a3025280-4ece-11eb-8b91-00a03a152d2b.png)|
|             U2A21                  |     All      |          |  -      |![middle](https://user-images.githubusercontent.com/12781303/103541880-a695d980-4ece-11eb-9b45-bea17505d434.png)|
|             U2A22                  |     All      |          |  -      |![คี](https://user-images.githubusercontent.com/12781303/103541884-a85f9d00-4ece-11eb-93cc-5ff8f7e8d797.png)|
|             U2A23                  |     All      |          |  -      |![Noti](https://user-images.githubusercontent.com/12781303/103541888-aac1f700-4ece-11eb-9d1d-fc52a83e6e00.png)|
|             U2A24                  |     All      |          |  -      |![skull](https://user-images.githubusercontent.com/12781303/103541892-ad245100-4ece-11eb-8224-27a5d7b88fda.png)|
|             U2A25                  |     All      |    ⨀      |  -      |![แฟล](https://user-images.githubusercontent.com/12781303/103542078-f96f9100-4ece-11eb-8a87-a7b872f442ef.png)|
|             U2A26                  |     All      |    ⨁      |  -      |![แฟลก](https://user-images.githubusercontent.com/12781303/103542082-faa0be00-4ece-11eb-8929-00aa80503ccc.png)|
|             U2A27                  |     All      |    ⨂      |  -      |![แฟลกภ](https://user-images.githubusercontent.com/12781303/103542088-fc6a8180-4ece-11eb-96a9-576f6eeea5bc.png)|
|             U2A28                  |     All      |    ⨃      |  -      |![แฟลกภั](https://user-images.githubusercontent.com/12781303/103542090-fd9bae80-4ece-11eb-8b7a-01531fd5eca2.png)|
|             U2A29                  |     All      |    ⨄      |  -      |![แฟลกภัค](https://user-images.githubusercontent.com/12781303/103542095-ff657200-4ece-11eb-9175-c997560d1115.png)|
|             U2A30                  |     All      |    ⨅      |  -      |![แฟลก่ภัีค](https://user-images.githubusercontent.com/12781303/103542102-012f3580-4ecf-11eb-9810-a006811e456c.png)|
|             U2A31                  |     All      |    ⨆      |  -      |![แฟลก่่ภัีค](https://user-images.githubusercontent.com/12781303/103542105-02f8f900-4ecf-11eb-859f-67e9106f045c.png)|
|             U2A32                  |     All      |    ⨇      |  -      |![แฟล้ก่่ภัีค](https://user-images.githubusercontent.com/12781303/103542110-04c2bc80-4ecf-11eb-902a-3fefdaabaeae.png)|
|             U2A33                  |     All      |    ⨈      |  -      |![วห](https://user-images.githubusercontent.com/12781303/103542415-7bf85080-4ecf-11eb-8f46-ea5f3d7fb7b5.png)|
|             U2A34                  |     All      |    ⨉      |  -      |![วัว](https://user-images.githubusercontent.com/12781303/103542418-7d297d80-4ecf-11eb-805d-842918b511bb.png)|
|             U2A35                  |     All      |    ⨊      |  -      |![หมู](https://user-images.githubusercontent.com/12781303/103542422-7ef34100-4ecf-11eb-94a8-e0c6f4365152.png)|
|             U2A36                  |     All      |    ⨋      |  -      |![ไ่](https://user-images.githubusercontent.com/12781303/103542426-80246e00-4ecf-11eb-92d9-f021311443a9.png)|
|             U2A37                  |     All      |    ⨌      |  -      |![tส้่าrยttย](https://user-images.githubusercontent.com/12781303/103542433-83b7f500-4ecf-11eb-8d04-6346016729a8.png)|
|             U2A38                  |     All      |    ⨍      |  -      |![สก](https://user-images.githubusercontent.com/12781303/103542441-861a4f00-4ecf-11eb-86cf-5e60f1c24191.png)|
|             U2A39                  |     All      |    ⨎      |  -      |![ส้่ายtย](https://user-images.githubusercontent.com/12781303/103542449-87e41280-4ecf-11eb-99d4-fff879e92f26.png)|
|             U2A40                  |     All      |    ⨏      |  -      |![ส้่ายttย](https://user-images.githubusercontent.com/12781303/103542454-89add600-4ecf-11eb-94f8-9b69ea01a826.png)|
|             U2A41                  |     All      |    ⨐      |  -      |![tส้่fาrยttย](https://user-images.githubusercontent.com/12781303/103542587-bcf06500-4ecf-11eb-8e38-af575cca1102.png)|
|             U2A42                  |     All      |    ⨑      |  -      |![tส้่fาrยttfย](https://user-images.githubusercontent.com/12781303/103542590-beba2880-4ecf-11eb-8224-296b2514b49a.png)|
|             U2A43                  |     All      |    ⨒      |  -      |![tส้่fาfrยfttfย](https://user-images.githubusercontent.com/12781303/103542595-bfeb5580-4ecf-11eb-82a7-20b9498f8c57.png)|
|             U2A44                  |     All      |    ⨓      |  -      |![tส้่fาrยfttfย](https://user-images.githubusercontent.com/12781303/103542600-c1b51900-4ecf-11eb-8d16-d01856d84fc8.png)|
|             U2A45                  |     All      |    ⨔      |  -      |![Af](https://user-images.githubusercontent.com/12781303/103542605-c37edc80-4ecf-11eb-985a-a2bbf7e1ef86.png)|
|             U2A46                  |     All      |    ⨕      |  -      |![สกาย](https://user-images.githubusercontent.com/12781303/103542611-c4b00980-4ecf-11eb-96f8-879d5ce8b467.png)|
|             U2A47                  |     All      |    ⨖      |  -      |![tส้่fาffgfgftrgยftgtffย](https://user-images.githubusercontent.com/12781303/103542614-c5e13680-4ecf-11eb-98c3-bbcbd0cfbe38.png)|
|             U2A48                  |     All      |    ⨗      |  -      |![tส้่fาffgfgftrgยfgtgtffย](https://user-images.githubusercontent.com/12781303/103542618-c7126380-4ecf-11eb-8440-4442d28f6492.png)|
|             U2A49                  |     All      |    ⨘      |  -      |![กุญแจ](https://user-images.githubusercontent.com/12781303/103542628-caa5ea80-4ecf-11eb-89f2-eac0031c063f.png)|
|             U2A50                  |     All      |    ⨙      |  -      |![เวล](https://user-images.githubusercontent.com/12781303/103542636-cc6fae00-4ecf-11eb-9c36-658522a5121c.png)|
|             U2A51                  |     All      |    ⨚      |  -      |![arrow](https://user-images.githubusercontent.com/12781303/103542642-d0033500-4ecf-11eb-8971-e95e3a0f8efa.png)|
|             U2A52                  |     All      |    ⨛      |  -      |![tส้่fาffgfftrยftgtffย](https://user-images.githubusercontent.com/12781303/103542645-d1ccf880-4ecf-11eb-8b4f-235561ca2b9c.png)|
|             U2A53                  |     All      |    ⨜      |  -      |![blue](https://user-images.githubusercontent.com/12781303/103542648-d42f5280-4ecf-11eb-8e9e-3c892e7755ea.png)|
|             U2A54                  |     All      |    ⨝      |  -      |![gree](https://user-images.githubusercontent.com/12781303/103542652-d5f91600-4ecf-11eb-8fb5-cee3e34fab56.png)|
|             U2A55                  |     All      |    ⨞      |  -      |![k](https://user-images.githubusercontent.com/12781303/103542655-d72a4300-4ecf-11eb-92ab-0b82c236d9f5.png)|
|             U2A56                  |     All      |    ⨟      |  -      |![o](https://user-images.githubusercontent.com/12781303/103542661-d98c9d00-4ecf-11eb-8dc8-ee8257509c52.png)|
|             U2A57                  |     All      |    ⨠      |  -      |![tส้่fาrrfffxffgdfgftrgยfgvtgtgffย](https://user-images.githubusercontent.com/12781303/103542674-ddb8ba80-4ecf-11eb-901a-9b16b8272f83.png)|
|             U2A58                  |     All      |    ⨡      |  -      |![pur](https://user-images.githubusercontent.com/12781303/103542679-df827e00-4ecf-11eb-8519-66b84a857686.png)|
|             U2A59                  |     All      |    ⨢      |  -      |![re](https://user-images.githubusercontent.com/12781303/103542683-e0b3ab00-4ecf-11eb-98b9-754292b028b9.png)|
|             U2A60                  |     All      |    ⨣      |  -      |![tส้่fาffgftrยftgtffย](https://user-images.githubusercontent.com/12781303/103542689-e27d6e80-4ecf-11eb-8d18-d1576d735537.png)|
|             U2A61                  |     All      |    ⨤      |  -      |![tส้่fาftrยfttfย](https://user-images.githubusercontent.com/12781303/103542690-e4473200-4ecf-11eb-859e-807167ede51d.png)|
|             U2A62                  |     All      |    ⨥      |  -      |![tส้่fาrfrfffxffgdfgftrgยfgvtgtgffย](https://user-images.githubusercontent.com/12781303/103542694-e5785f00-4ecf-11eb-883f-a813fb6b1a61.png)|
|             U2A63                  |     All      |    ⨦      |  -      |![tส้่fาfgftrยfttffย](https://user-images.githubusercontent.com/12781303/103542699-e7422280-4ecf-11eb-810f-5fd2c994af45.png)|
|             U2A64                  |     All      |    ⨧      |  -      |![tส้่fาfftrยfttfย](https://user-images.githubusercontent.com/12781303/103542708-ead5a980-4ecf-11eb-96a9-7ed225b7b7b6.png)|
|             U2A65                  |     All      |    ⨨      |  -      |![tส้่fาfgftrยfttfย](https://user-images.githubusercontent.com/12781303/103542712-ec9f6d00-4ecf-11eb-9e5e-b464ec20e615.png)|
|             U2A66                  |     All      |    ⨩      |  -      |![tส้่fาffgftrยfttffย](https://user-images.githubusercontent.com/12781303/103542714-edd09a00-4ecf-11eb-8a64-b15cd3c93c4c.png)|
|             U2A67                  |     All      |    ⨪      |  -      |![dis](https://user-images.githubusercontent.com/12781303/103542724-f032f400-4ecf-11eb-921b-b40c5e577aba.png)|
|             U2A68                  |     All      |    ⨫      |  -      |![face](https://user-images.githubusercontent.com/12781303/103542727-f1642100-4ecf-11eb-8420-b9be4b1fd8ae.png)|
|             U2A69                  |     All      |    ⨬      |  -      |![Yt](https://user-images.githubusercontent.com/12781303/103542733-f32de480-4ecf-11eb-9739-fc4d9b1b46c2.png)|
|             U2A70                  |     All      |    ⨭      |  -      |![ภาพถ่ายหน้าจอ 2564-05-05 เวลา 08 58 16](https://user-images.githubusercontent.com/12781303/117089554-08ccf100-ad80-11eb-9ddd-7932e131849e.png)|
|             U2A71                  |     All      |    ⨮      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 10 04](https://user-images.githubusercontent.com/12781303/118394942-f1d8a980-b671-11eb-934f-f6f11de840e1.png)|
|             U2A72                  |     All      |    ⨯      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 10 29](https://user-images.githubusercontent.com/12781303/118394959-0157f280-b672-11eb-8cce-0d1259c1e64f.png)|
|             U2A73                  |     All      |    ⨰      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 11 00](https://user-images.githubusercontent.com/12781303/118394978-13399580-b672-11eb-94cf-95b979a012cb.png)|
|             U2A74                  |     All      |    ⨱      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 11 25](https://user-images.githubusercontent.com/12781303/118394985-22204800-b672-11eb-8191-652ba64d0e67.png)|
|             U2A75                  |     All      |    ⨲      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 11 48](https://user-images.githubusercontent.com/12781303/118394995-306e6400-b672-11eb-956b-77dd26ca9f00.png)|
|             U2A76                  |     All      |    ⨳      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 12 11](https://user-images.githubusercontent.com/12781303/118395001-3cf2bc80-b672-11eb-9405-706abebd9120.png)|
|             U2A77                  |     All      |    ⨴      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 12 29](https://user-images.githubusercontent.com/12781303/118395007-47ad5180-b672-11eb-9862-a04977d33e23.png)|
|             U2A78                  |     All      |    ⨵      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 12 44](https://user-images.githubusercontent.com/12781303/118395012-509e2300-b672-11eb-8eda-e3ea90e36aa0.png)|
|             U2A79                  |     All      |    ⨶      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 13 08](https://user-images.githubusercontent.com/12781303/118395025-5eec3f00-b672-11eb-86e0-8ab516ab4712.png)|
|             U2A80                  |     All      |    ⨷      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 13 25](https://user-images.githubusercontent.com/12781303/118395033-690e3d80-b672-11eb-982d-01d1c28ac43c.png)|
|             U2A81                  |     All      |    ⨸      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 13 42](https://user-images.githubusercontent.com/12781303/118395037-73303c00-b672-11eb-85ea-bff8980aa13e.png)|
|             U2A82                  |     All      |    ⨹      |  -      |![ภาพถ่ายหน้าจอ 2564-05-16 เวลา 18 14 02](https://user-images.githubusercontent.com/12781303/118395049-7f1bfe00-b672-11eb-8619-b3b00575f936.png)|
|             U2A83                  |     All      |    ⨺      |  -      |![accept](https://user-images.githubusercontent.com/12781303/118395059-9955dc00-b672-11eb-8382-5e40821d72a6.png)|
|             U2A84                  |     All      |    ⨻      |  -      |![add](https://user-images.githubusercontent.com/12781303/118395068-a377da80-b672-11eb-886c-e12d31f102c6.png)|
|             U2A85                  |     All      |    ⨼      |  -      |![arrow_blue_first](https://user-images.githubusercontent.com/12781303/118395073-ad014280-b672-11eb-8c48-caecbcb6d28a.png)|
|             U2A86                  |     All      |    ⨽      |  -      |![arrow_blue_last](https://user-images.githubusercontent.com/12781303/118395076-b2f72380-b672-11eb-90d9-869cb96cf695.png)|
|             U2A87                  |     All      |    ⨾      |  -      |![arrow_down](https://user-images.githubusercontent.com/12781303/118395079-b8546e00-b672-11eb-9223-57dfe76bfa7a.png)|
|             U2A88                  |     All      |    ⨿      |  -      |![blip_orange](https://user-images.githubusercontent.com/12781303/118395087-c904e400-b672-11eb-9259-489c297988af.png)|
|             U2A89                  |     All      |    ⩀      |  -      |![arrow_up](https://user-images.githubusercontent.com/12781303/118395102-d6ba6980-b672-11eb-8877-6d9b6284fe89.png)|
|             U2A90                  |     All      |    ⩁      |  -      |![button_xbox_a](https://user-images.githubusercontent.com/12781303/118395111-de7a0e00-b672-11eb-806a-57499a42151e.png)|
|             U2A91                  |     All      |    ⩂      |  -      |![button_xbox_b](https://user-images.githubusercontent.com/12781303/118395117-e2a62b80-b672-11eb-9b82-89e9e5fe9129.png)|
|             U2A92                  |     All      |    ⩃      |  -      |![button_xbox_x](https://user-images.githubusercontent.com/12781303/118395132-ea65d000-b672-11eb-9bb2-844f8146d623.png)|
|             U2A93                  |     All      |    ⩄      |  -      |![button_xbox_y](https://user-images.githubusercontent.com/12781303/118395137-efc31a80-b672-11eb-87ba-bcff2d888828.png)|
|             U2A94                  |     All      |    ⩅      |  -      |![character_add](https://user-images.githubusercontent.com/12781303/118395144-f81b5580-b672-11eb-8c51-9b6ccfd50c90.png)|
|             U2A95                  |     All      |    ⩆      |  -      |![character_dialogue](https://user-images.githubusercontent.com/12781303/118395146-fc477300-b672-11eb-9c67-4b53c8b28b7b.png)|
|             U2A96                  |     All      |    ⩇      |  -      |![character_edit](https://user-images.githubusercontent.com/12781303/118395151-023d5400-b673-11eb-904a-25c6faa62b88.png)|
|             U2A97                  |     All      |    ⩈      |  -      |![character_heart](https://user-images.githubusercontent.com/12781303/118395156-06697180-b673-11eb-81cb-b2689e41564d.png)|
|             U2A98                  |     All      |    ⩉      |  -      |![character_lock](https://user-images.githubusercontent.com/12781303/118395159-0a958f00-b673-11eb-9893-76365cc2052a.png)|
|             U2A99                  |     All      |    ⩊      |  -      |![chest_item](https://user-images.githubusercontent.com/12781303/118395171-14b78d80-b673-11eb-9c84-f12d3afcce52.png)|
|             U2B01                  |     All      |    ⩋      |  -      |![checkmark](https://user-images.githubusercontent.com/12781303/118395185-2c8f1180-b673-11eb-965e-2663e1265181.png)|
|             U2B02                  |     All      |    ⩌      |  -      |![clear](https://user-images.githubusercontent.com/12781303/118395189-31ec5c00-b673-11eb-898f-8a7b4503a3a2.png)|
|             U2B03                  |     All      |    ⩍      |  -      |![clock_play](https://user-images.githubusercontent.com/12781303/118395199-39136a00-b673-11eb-9f27-7fe8264e4f3b.png)|
|             U2B04                  |     All      |    ⩎      |  -      |![clock_stop](https://user-images.githubusercontent.com/12781303/118395200-3a449700-b673-11eb-828f-ca86123a9e20.png)|
|             U2B05                  |     All      |    ⩏      |  -      |![clock](https://user-images.githubusercontent.com/12781303/118395201-3add2d80-b673-11eb-99a6-62302639232e.png)|
|             U2B06                  |     All      |    ⩐      |  -      |![coins](https://user-images.githubusercontent.com/12781303/118395241-77a92480-b673-11eb-9635-2689f281c2fe.png)|
|             U2B07                  |     All      |    ⩑      |  -      |![color_edit](https://user-images.githubusercontent.com/12781303/118395243-78da5180-b673-11eb-8e95-c9e83df544bb.png)|
|             U2B08                  |     All      |    ⩒      |  -      |![color_swatch](https://user-images.githubusercontent.com/12781303/118395244-7972e800-b673-11eb-8b09-927e7b79f56a.png)|
|             U2B09                  |     All      |    ⩓      |  -      |![computer](https://user-images.githubusercontent.com/12781303/118395245-7972e800-b673-11eb-9fcd-504b10a9ab33.png)|
|             U2B10                  |     All      |    ⩔      |  -      |![console](https://user-images.githubusercontent.com/12781303/118395246-7a0b7e80-b673-11eb-9091-e5e775dd5587.png)|
|             U2B11                  |     All      |    ⩕      |  -      |![delete](https://user-images.githubusercontent.com/12781303/118395248-7a0b7e80-b673-11eb-927e-9f08d42364ea.png)|
|             U2B12                  |     All      |    ⩖      |  -      |![disk_multiple](https://user-images.githubusercontent.com/12781303/118395249-7aa41500-b673-11eb-9f7d-c699e8cbe165.png)|
|             U2B13                  |     All      |    ⩗      |  -      |![enemy](https://user-images.githubusercontent.com/12781303/118395250-7b3cab80-b673-11eb-954d-d10f8ec20c7c.png)|
|             U2B14                  |     All      |    ⩘      |  -      |![folder](https://user-images.githubusercontent.com/12781303/118395251-7b3cab80-b673-11eb-8c11-62763c092a3f.png)|
|             U2B15                  |     All      |    ⩙      |  -      |![linux_logo](https://user-images.githubusercontent.com/12781303/118395252-7bd54200-b673-11eb-9471-d004bbfeaddd.png)|
|             U2B16                  |     All      |    ⩚      |  -      |![mac_logo](https://user-images.githubusercontent.com/12781303/118395254-7c6dd880-b673-11eb-8b5a-6a658147b23c.png)|
|             U2B17                  |     All      |    ⩛      |  -      |![palette](https://user-images.githubusercontent.com/12781303/118395255-7c6dd880-b673-11eb-9cfc-c8a64d271e79.png)|
|             U2B18                  |     All      |    ⩜      |  -      |![wizard](https://user-images.githubusercontent.com/12781303/118395256-7d066f00-b673-11eb-9b36-3e97f90fa941.png)|
|             U2B19                  |     All      |    ⩝      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 20 04](https://user-images.githubusercontent.com/12781303/123561243-7b32de00-d7d1-11eb-9a25-7759e8f28e00.png)|
|             U2B20                  |     All      |    ⩞      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 20 16](https://user-images.githubusercontent.com/12781303/123561246-7cfca180-d7d1-11eb-967d-9d794c355a2b.png)|
|             U2B21                  |     All      |    ⩟      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 20 23](https://user-images.githubusercontent.com/12781303/123561247-7d953800-d7d1-11eb-84bb-f90ddd354e17.png)|
|             U2B22                  |     All      |    ⩠      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 20 29](https://user-images.githubusercontent.com/12781303/123561248-7e2dce80-d7d1-11eb-8532-1328f2b2c234.png)|
|             U2B23                  |     All      |    ⩡      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 20 36](https://user-images.githubusercontent.com/12781303/123561249-7ec66500-d7d1-11eb-9bd3-a728eb77c189.png)|
|             U2B24                  |     All      |    ⩢      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 20 42](https://user-images.githubusercontent.com/12781303/123561250-7ec66500-d7d1-11eb-9f5c-1ff9f5a5682c.png)|
|             U2B25                  |     All      |    ⩣      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 20 50](https://user-images.githubusercontent.com/12781303/123561251-7f5efb80-d7d1-11eb-83b3-a9b0f542200a.png)|
|             U2B26                  |     All      |    ⩤      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 20 56](https://user-images.githubusercontent.com/12781303/123561252-7ff79200-d7d1-11eb-963c-171f606a159f.png)|
|             U2B27                  |     All      |    ⩥      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 21 02](https://user-images.githubusercontent.com/12781303/123561253-7ff79200-d7d1-11eb-8eb7-f88c1d1e9429.png)|
|             U2B28                  |     All      |    ⩦      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 21 09](https://user-images.githubusercontent.com/12781303/123561254-80902880-d7d1-11eb-8212-c30f41570dbd.png)|
|             U2B29                  |     All      |    ⩧      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 21 14](https://user-images.githubusercontent.com/12781303/123561257-8128bf00-d7d1-11eb-9965-b35fc5e7bdf9.png)|
|             U2B30                  |     All      |    ⩨      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 21 20](https://user-images.githubusercontent.com/12781303/123561258-8128bf00-d7d1-11eb-8190-20d6eed7b6c3.png)|
|             U2B31                  |     All      |    ⩩      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 21 26](https://user-images.githubusercontent.com/12781303/123561259-81c15580-d7d1-11eb-9f7c-96d92d928c87.png)|
|             U2B32                  |     All      |    ⩪      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 21 32](https://user-images.githubusercontent.com/12781303/123561261-81c15580-d7d1-11eb-9121-dc57e1b1f72e.png)|
|             U2B33                  |     All      |    ⩫      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 21 38](https://user-images.githubusercontent.com/12781303/123561262-8259ec00-d7d1-11eb-88a2-0c88a776a981.png)|
|             U2B34                  |     All      |    ⩬      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 21 42](https://user-images.githubusercontent.com/12781303/123561264-82f28280-d7d1-11eb-9e48-c056e57b9c76.png)|
|             U2B35                  |     All      |    ⩭      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 21 47](https://user-images.githubusercontent.com/12781303/123561266-82f28280-d7d1-11eb-8cd6-1939ec7a99a2.png)|
|             U2B36                  |     All      |    ⩮      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 21 54](https://user-images.githubusercontent.com/12781303/123561267-838b1900-d7d1-11eb-8e29-ba44dfe9e621.png)|
|             U2B37                  |     All      |    ⩯      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 22 01](https://user-images.githubusercontent.com/12781303/123561268-8423af80-d7d1-11eb-88e4-0d704cfa990d.png)|
|             U2B38                  |     All      |    ⩰      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 22 06](https://user-images.githubusercontent.com/12781303/123561270-8423af80-d7d1-11eb-8334-d11a100563fc.png)|
|             U2B39                  |     All      |    ⩱      |  -      |![ภาพถ่ายหน้าจอ 2564-06-28 เวลา 05 22 12](https://user-images.githubusercontent.com/12781303/123561272-84bc4600-d7d1-11eb-8f0f-0d18f0616516.png)|


